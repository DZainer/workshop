# students-ci-cd
Students API with a CI/CD pipeline using AWS CodePipeline
